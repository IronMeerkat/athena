package com.ironmeerkat.athena

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * PolicyEngine orchestrates policy decisions for foreground apps and
 * websites. It consults the LocalPolicyStore and DecisionCache for
 * immediate answers and falls back to AthenaApiClient when a server
 * decision is required. Clients should call onForegroundChange() from
 * an AccessibilityService or other observer whenever the foreground
 * app or URL changes.
 */
class PolicyEngine private constructor(private val context: Context) {

    private val localPolicyStore: LocalPolicyStore = LocalPolicyStore.getInstance(context)
    private val decisionCache: DecisionCache = DecisionCache.getInstance()
    private val apiClient: AthenaApiClient = AthenaApiClient.getInstance(context)
    private val settingsRepository: SettingsRepository = SettingsRepository.getInstance(context)
    private val hardcodeController: HardcodeController = HardcodeController.getInstance(context)

    // Coroutine scope for background work
    private val scope = CoroutineScope(Dispatchers.Default)

    companion object {
        @Volatile
        private var instance: PolicyEngine? = null

        fun getInstance(context: Context): PolicyEngine {
            return instance ?: synchronized(this) {
                instance ?: PolicyEngine(context.applicationContext).also { instance = it }
            }
        }
    }

    /**
     * Called when the foreground app or URL changes. Determines whether
     * access should be allowed immediately, blocked, or deferred to the
     * server for a decision. Blocks are surfaced via the BlockOverlayController.
     */
    fun onForegroundChange(packageName: String, url: String?) {
        Log.d("Athena", "Foreground changed: pkg=$packageName url=$url")
        // If paused and not hardcode mode, allow immediately
        if (settingsRepository.isPaused() && !hardcodeController.isActive()) {
            Log.d("Athena", "PolicyEngine: device is paused; allowing")
            return
        }
        // Check deterministic whitelist and temporary rules
        val localAllowed = localPolicyStore.isAllowed(packageName, url)
        if (localAllowed) {
            Log.d("Athena", "PolicyEngine: locally allowed")
            return
        }
        // Check decision cache
        val cached = decisionCache.get(packageName, url)
        if (cached != null) {
            Log.d("Athena", "PolicyEngine: cached decision=${cached.decision}")
            if (cached.decision == Decision.Allow) {
                return
            }
            // Block if cached decision is block
            showBlockOverlay(cached.reason ?: "Blocked by policy")
            return
        }
        // Fallback to server; start decision flow
        scope.launch {
            try {
                val response = apiClient.deviceAttempt(packageName, url)
                Log.d("Athena", "PolicyEngine: server run_id=${response.runId}")
                // Listen for SSE events for decision
                apiClient.listenForDecision(response.runId) { event ->
                    when (event.decision) {
                        Decision.Allow -> {
                            decisionCache.put(packageName, url, Decision.Allow, event.ttl)
                            Log.d("Athena", "PolicyEngine: decision ALLOW from server")
                        }
                        Decision.Block -> {
                            decisionCache.put(packageName, url, Decision.Block, event.ttl)
                            Log.d("Athena", "PolicyEngine: decision BLOCK from server: ${event.message}")
                            showBlockOverlay(event.message ?: "Blocked by server")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("Athena", "PolicyEngine: error contacting server", e)
                // Offline or error: block by default but allow override
                showBlockOverlay("Unable to reach server. Defaulting to block.")
            }
        }
    }

    /**
     * Toggle the pause state. When paused the PolicyEngine allows all apps
     * except when hardcode mode is active. The state persists in
     * SettingsRepository.
     */
    fun setPause(paused: Boolean) {
        Log.d("Athena", "PolicyEngine: setting pause=$paused")
        settingsRepository.setPause(paused)
    }

    /**
     * Commit hardcode mode for the given duration in milliseconds. During
     * hardcode mode the device cannot be unpaused or overridden. This
     * state persists locally until expiry.
     */
    fun commitHardcode(durationMs: Long) {
        Log.d("Athena", "PolicyEngine: committing hardcode for ${durationMs / 1000} seconds")
        hardcodeController.commit(durationMs)
    }

    /**
     * Show the block overlay with a given reason. This delegates to the
     * BlockOverlayController and ensures it runs on the main thread.
     */
    private fun showBlockOverlay(reason: String) {
        // The overlay is part of the UI layer; call into it on the main thread
        Log.d("Athena", "PolicyEngine: showing block overlay: $reason")
        BlockOverlayController.getInstance(context).showBlock(reason)
    }
}

/**
 * Enum representing an allow or block decision. In a more sophisticated
 * implementation this could include additional states such as
 * `Pending`.
 */
enum class Decision { Allow, Block }