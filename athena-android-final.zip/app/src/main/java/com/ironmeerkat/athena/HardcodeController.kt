package com.ironmeerkat.athena

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.util.Log

/**
 * HardcodeController enforces "hardcode mode" which prevents the user from
 * bypassing the block screen, pausing, or altering deterministic rules
 * until a specified expiry time. On supported devices this also blocks
 * uninstallation via DevicePolicyManager.
 */
class HardcodeController private constructor(private val context: Context) {

    private val settingsRepository = SettingsRepository.getInstance(context)

    companion object {
        @Volatile private var INSTANCE: HardcodeController? = null

        fun getInstance(context: Context): HardcodeController {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: HardcodeController(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    /**
     * Commit to hardcode mode for the specified duration in milliseconds.
     * This sets an expiry timestamp and optionally blocks uninstallation if
     * the device has been provisioned as a Device Owner.
     */
    fun commit(durationMs: Long) {
        val expiry = System.currentTimeMillis() + durationMs
        settingsRepository.setHardcodeUntil(expiry)
        Log.d("Athena", "HardcodeController: committed until ${java.util.Date(expiry)}")
        // Attempt to block uninstallation via DevicePolicyManager. If not
        // available (e.g. not device owner) this call will fail silently.
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        val admin = ComponentName(context, AthenaDeviceAdminReceiver::class.java)
        try {
            dpm?.setUninstallBlocked(admin, context.packageName, true)
        } catch (e: Exception) {
            Log.w("Athena", "HardcodeController: setUninstallBlocked failed", e)
        }
    }

    /**
     * Returns true if hardcode mode is currently active.
     */
    fun isActive(): Boolean {
        return System.currentTimeMillis() < settingsRepository.getHardcodeUntil()
    }

    /**
     * Returns remaining time in milliseconds, or 0 if inactive.
     */
    fun remainingTime(): Long {
        val until = settingsRepository.getHardcodeUntil()
        return maxOf(0, until - System.currentTimeMillis())
    }
}