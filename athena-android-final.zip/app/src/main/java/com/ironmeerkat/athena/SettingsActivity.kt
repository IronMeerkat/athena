package com.ironmeerkat.athena

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.ironmeerkat.athena.ui.theme.AthenaTheme
import android.util.Log

/**
 * SettingsActivity allows the user to manage pause state, deterministic
 * whitelist and hardcode mode. The UI here is intentionally simple to
 * make it easy for developers unfamiliar with Kotlin to follow.
 */
class SettingsActivity : ComponentActivity() {

    private val policyEngine by lazy { PolicyEngine.getInstance(this) }
    private val settingsRepository by lazy { SettingsRepository.getInstance(this) }
    private val hardcodeController by lazy { HardcodeController.getInstance(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("Athena", "SettingsActivity created")
        setContent {
            AthenaTheme {
                SettingsScreen(
                    paused = settingsRepository.isPaused(),
                    onPauseChanged = { paused -> policyEngine.setPause(paused) },
                    onCommitHardcode = { durationMs -> policyEngine.commitHardcode(durationMs) },
                    hardcodeActive = hardcodeController.isActive(),
                    hardcodeRemaining = hardcodeController.remainingTime()
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(
    paused: Boolean,
    onPauseChanged: (Boolean) -> Unit,
    onCommitHardcode: (Long) -> Unit,
    hardcodeActive: Boolean,
    hardcodeRemaining: Long
) {
    var pauseState by remember { mutableStateOf(paused) }
    Column {
        Text(text = "Settings", style = MaterialTheme.typography.headlineSmall)
        // Pause toggle
        RowToggle(
            label = if (pauseState) "Resume" else "Pause",
            checked = pauseState,
            onCheckedChange = { checked ->
                pauseState = checked
                onPauseChanged(checked)
            }
        )
        // Hardcode mode commit button (disabled if already active)
        Button(
            onClick = { onCommitHardcode(24 * 60 * 60 * 1000L) },
            enabled = !hardcodeActive
        ) {
            val text = if (hardcodeActive) {
                "Hardcode active: ${hardcodeRemaining / 1000 / 60} min left"
            } else {
                "Commit Hardcode (24h)"
            }
            Text(text = text)
        }
    }
}

@Composable
fun RowToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(text = label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}