package com.ironmeerkat.athena

import android.accessibilityservice.AccessibilityService as AndroidAccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * AccessibilityService listens for accessibility events to detect
 * changes in the foreground application and, where possible, the active
 * URL. It forwards these events to the PolicyEngine. This service must
 * be explicitly enabled by the user in the Android accessibility
 * settings.
 */
class AccessibilityService : AndroidAccessibilityService() {

    private val policyEngine: PolicyEngine by lazy { PolicyEngine.getInstance(this) }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        // We're interested in window state changes (app switch) and text selection
        // changes (URL changes). These heuristics are simplistic but sufficient
        // for demonstration.
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED -> {
                val pkg = event.packageName?.toString() ?: return
                // Attempt to extract a URL from the event. In practice you'd use more
                // robust methods to inspect the view hierarchy.
                val url = extractUrl(event)
                Log.d("Athena", "Accessibility event: pkg=$pkg url=$url type=${event.eventType}")
                policyEngine.onForegroundChange(pkg, url)
            }
        }
    }

    override fun onInterrupt() {
        Log.d("Athena", "AccessibilityService interrupted")
    }

    private fun extractUrl(event: AccessibilityEvent): String? {
        val text = event.text?.firstOrNull()?.toString()
        return if (text != null && (text.startsWith("http://") || text.startsWith("https://"))) {
            text
        } else {
            null
        }
    }
}