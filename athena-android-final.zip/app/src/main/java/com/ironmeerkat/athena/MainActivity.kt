package com.ironmeerkat.athena

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import com.ironmeerkat.athena.ui.theme.AthenaTheme
import android.util.Log

/**
 * MainActivity is the entry point for the Athena application. It hosts the
 * Compose UI and initializes the PolicyEngine. From here users can chat with
 * Athena and navigate to the Settings screen. Logging is added for
 * troubleshooting; filter logcat with `adb logcat | grep Athena:` to see
 * messages prefixed with the tag "Athena".
 */
class MainActivity : ComponentActivity() {

    private val policyEngine by lazy { PolicyEngine.getInstance(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("Athena", "MainActivity created")

        setContent {
            AthenaTheme {
                // Chat UI is displayed by default
                ChatScreen(policyEngine)
            }
        }
    }
}

/**
 * ChatScreen renders a very simple chat interface. Messages are appended to
 * a local list when the user presses send. In a full implementation this
 * would interact with AthenaApiClient and stream responses from the
 * server via SSE. To keep things simple for now the responses are
 * echoed locally.
 */
@Composable
fun ChatScreen(policyEngine: PolicyEngine) {
    var input by remember { mutableStateOf(TextFieldValue("")) }
    val messages = remember { mutableStateListOf<String>() }

    Column(modifier = Modifier.fillMaxSize()) {
        // Display existing messages
        for (msg in messages) {
            Text(text = msg, style = MaterialTheme.typography.bodyLarge)
        }
        // Text input for composing a new message
        BasicTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.weight(1f)
        )
        Button(onClick = {
            val text = input.text.trim()
            if (text.isNotEmpty()) {
                // Add the user's message
                messages.add("You: $text")
                // TODO: send the message to the server via runsCreate() and stream
                // the response. For now we echo the input as a placeholder.
                messages.add("Athena: Echo - $text")
                Log.d("Athena", "User sent message: $text")
                input = TextFieldValue("")
            }
        }) {
            Text(text = "Send")
        }
    }
}