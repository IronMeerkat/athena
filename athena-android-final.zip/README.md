# Athena Android

This repository contains a from‑scratch rebuild of the Athena Android app as described in the [proposal](../ATHENA-ANDROID-PROPOSAL.md).  The goal of this project is to provide a clean, easy‑to‑understand codebase that integrates with Athena’s back‑ends while keeping the Kotlin surface area approachable for developers new to the language.

> **Important:** The `google‑services.json` file required to enable Firebase (if desired) is **not** included here.  Place your own copy under `app/` when configuring the app.

## Overview

Athena opens directly to a chat interface where users can converse with Athena’s agents.  In the background the app monitors foreground apps and web URLs to enforce digital wellbeing policies.  When access is blocked a full‑screen overlay is displayed, offering the ability to appeal or temporarily override the decision.

The implementation is broken into clear layers:

- **UI Layer (Jetpack Compose)** – Contains the chat screen, block overlay and settings UI.  Compose is used exclusively for clarity and minimal boilerplate.
 - **Services** – A custom `AccessibilityService` observes foreground changes and informs the policy engine.  A lightweight `ForegroundMonitorService` keeps the app alive when running in the background.
- **Policy Layer** – `PolicyEngine` decides whether to allow or block apps/websites.  It consults a local Room database (`LocalPolicyStore`) and an in‑memory `DecisionCache`, falling back to the remote DRF API via `AthenaApiClient` if necessary.
- **Storage** – Policy rules and cached decisions are persisted using Room.  User settings (pause state, hardcode expiry, device ID) are stored in `SharedPreferences` via `SettingsRepository`.
- **Backend Integration** – Network calls are defined in `AthenaApiClient` using Retrofit and OkHttp.  Authentication is stubbed in `AuthManager` and should be replaced with your JWT/Firebase integration.

Throughout the code you will see many log statements prefixed with **“Athena”**.  You can inspect the app’s behaviour at runtime with:

```bash
adb logcat | grep Athena:
```

## Project Structure

```
athena-android/
│   build.gradle            # Root gradle configuration (minimal)
│   settings.gradle         # Declares the app module
│   README.md               # This file
│   docs/                   # Additional documentation and UML diagrams
└── app/
    ├── build.gradle        # Android module configuration (Compose, Retrofit, Room)
    ├── proguard-rules.pro  # ProGuard rules (unused by default)
    ├── src/main/
    │   ├── AndroidManifest.xml
    │   ├── java/com/ironmeerkat/athena/
    │   │   ├── AthenaApplication.kt       # Application class
    │   │   ├── MainActivity.kt            # Chat entrypoint
    │   │   ├── SettingsActivity.kt        # Settings UI
    │   │   ├── BlockOverlayActivity.kt    # Full‑screen block overlay
    │   │   ├── PolicyEngine.kt            # Core policy logic
    │   │   ├── LocalPolicyStore.kt        # Room database and helper
    │   │   ├── DecisionCache.kt           # In‑memory decision cache
    │   │   ├── AthenaApiClient.kt         # Retrofit API client
    │   │   ├── AuthManager.kt             # Stubbed auth manager
    │   │   ├── SettingsRepository.kt      # SharedPrefs backed settings
    │   │   ├── HardcodeController.kt      # Hardcode mode logic
    │   │   ├── AthenaDeviceAdminReceiver.kt # Device admin receiver
    │   │   ├── ForegroundMonitorService.kt  # Foreground service
    │   │   ├── AccessibilityService.kt    # Accessibility service
    │   │   ├── BlockOverlayController.kt  # Overlay launcher
    │   │   └── ui/theme/                  # Compose theme files
    │   └── res/                           # Android resources (themes, strings, xml)
    └── google-services.json               # Add your own copy (not included)
```

## Building & Running

1. **Prerequisites** – Install [Android Studio](https://developer.android.com/studio)  Hedgehog or later.  Make sure you have an emulator or physical device running Android 10 (API 29) or higher.
2. **Clone** – Check out this repository and open the `athena-android` directory in Android Studio.
3. **Sync Gradle** – Let Android Studio download dependencies.  You may see warnings about missing `google‑services.json`; this is expected if you are not integrating Firebase.
4. **Run** – Build and run the `app` module.  Grant the requested accessibility and overlay permissions when prompted.  Use logcat to observe decision making.

## Extending the App

This codebase is intentionally minimal.  To fully integrate with Athena’s back‑ends you will need to:

- Replace the placeholder `BASE_URL` in `AthenaApiClient` with your DRF gateway host.
- Implement authentication in `AuthManager` (e.g. JWT retrieval and refresh).
- Flesh out the SSE and WebSocket listeners for streaming decisions and appeal chat.
 - Enhance the `AccessibilityService` to reliably extract URLs from popular browsers.
- Build out the Chat UI with message streaming and quick actions as described in the proposal.
- Harden security (encryption, certificate pinning) and privacy (filter PII from logs).

For a visual overview of the architecture please see the diagrams in `docs/architecture.md`.