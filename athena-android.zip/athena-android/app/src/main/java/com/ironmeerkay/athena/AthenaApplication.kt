package com.ironmeerkay.athena

import android.app.Application
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

/**
 * AthenaApplication is the top-level Application class. It lazily
 * initializes singletons such as the database and policy engine. The
 * Android framework instantiates this class before any Activity or
 * Service runs.
 */
class AthenaApplication : Application() {

    // Create a scope for launching coroutines tied to the application's lifecycle.
    private val applicationScope = CoroutineScope(SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        Log.d("Athena", "AthenaApplication created")
        // Initialize the singleton PolicyEngine instance
        PolicyEngine.getInstance(this)
    }
}