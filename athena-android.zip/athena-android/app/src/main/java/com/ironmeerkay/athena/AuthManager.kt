package com.ironmeerkay.athena

import android.content.Context
import android.util.Log

/**
 * AuthManager is responsible for obtaining and refreshing access tokens for
 * authenticated calls to the DRF gateway. This simple implementation
 * stores a token in memory and does not support refresh tokens. Replace
 * this with your preferred authentication mechanism (JWT or Firebase ID
 * tokens) as needed.
 */
class AuthManager private constructor(private val context: Context?) {

    private var token: String? = null

    companion object {
        @Volatile private var INSTANCE: AuthManager? = null

        fun getInstance(context: Context?): AuthManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AuthManager(context).also { INSTANCE = it }
            }
        }
    }

    /**
     * Returns the current access token, or null if not authenticated.
     */
    fun getAccessToken(): String? = token

    /**
     * Stores an access token. In a real implementation this might be
     * persisted to EncryptedSharedPreferences.
     */
    fun setAccessToken(token: String) {
        Log.d("Athena", "AuthManager: new token set")
        this.token = token
    }

    /**
     * Dummy refresh function. Expand this to call your auth provider's
     * refresh endpoint or Firebase's token refresh as appropriate.
     */
    fun refresh() {
        Log.d("Athena", "AuthManager: refresh called (stub)")
    }
}