package com.ironmeerkay.athena

import android.util.Log
import java.util.concurrent.ConcurrentHashMap

/**
 * DecisionCache caches allow/block decisions returned from the server. Each
 * entry is keyed by package and optional URL, and contains a TTL. When the
 * TTL expires the entry is removed. Caching decisions reduces the number
 * of network calls for repeated sites and apps.
 */
class DecisionCache private constructor() {

    private data class Entry(val decision: Decision, val reason: String?, val expiresAt: Long)

    private val map = ConcurrentHashMap<String, Entry>()

    companion object {
        @Volatile private var INSTANCE: DecisionCache? = null

        fun getInstance(): DecisionCache {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: DecisionCache().also { INSTANCE = it }
            }
        }
    }

    /**
     * Build a cache key from package and URL. URLs are optional; if null
     * the key is just the package name. Otherwise the key is package
     * concatenated with the URL.
     */
    private fun key(pkg: String, url: String?): String = if (url.isNullOrEmpty()) pkg else "$pkg|$url"

    /**
     * Return a cached decision if present and not expired. If expired the
     * entry is removed and null is returned.
     */
    fun get(pkg: String, url: String?): CachedDecision? {
        val k = key(pkg, url)
        val now = System.currentTimeMillis()
        val entry = map[k]
        return if (entry != null) {
            if (entry.expiresAt > now) {
                CachedDecision(entry.decision, entry.reason, (entry.expiresAt - now) / 1000)
            } else {
                map.remove(k)
                null
            }
        } else {
            null
        }
    }

    /**
     * Put a decision into the cache with a TTL in seconds.
     */
    fun put(pkg: String, url: String?, decision: Decision, ttlSeconds: Long, reason: String? = null) {
        val k = key(pkg, url)
        val expiresAt = System.currentTimeMillis() + ttlSeconds * 1000
        map[k] = Entry(decision, reason, expiresAt)
        Log.d("Athena", "DecisionCache: cached decision $decision for $k ttl=${ttlSeconds}s")
    }
}

/**
 * A wrapper returned by DecisionCache.get() describing a cached decision.
 */
data class CachedDecision(val decision: Decision, val reason: String?, val ttlSeconds: Long)