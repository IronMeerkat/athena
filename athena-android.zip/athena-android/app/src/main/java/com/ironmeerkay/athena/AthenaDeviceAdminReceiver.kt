package com.ironmeerkay.athena

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Broadcast receiver required for DevicePolicyManager interactions. When
 * Athena is provisioned as a device or profile owner this receiver
 * enables calls such as setUninstallBlocked(). It logs lifecycle events
 * for troubleshooting.
 */
class AthenaDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.d("Athena", "DeviceAdminReceiver: enabled")
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence? {
        Log.d("Athena", "DeviceAdminReceiver: disable requested")
        return "Disabling device admin may prevent hardcode mode from working properly."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.d("Athena", "DeviceAdminReceiver: disabled")
    }
}