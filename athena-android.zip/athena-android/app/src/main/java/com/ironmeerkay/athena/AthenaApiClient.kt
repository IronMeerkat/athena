package com.ironmeerkay.athena

import android.content.Context
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/**
 * AthenaApiClient encapsulates all network calls to the DRF gateway. It uses
 * Retrofit to define the REST APIs and OkHttp's EventSource to listen
 * for server-sent events (SSE). Before making network calls you may
 * need to configure authentication headers in AuthManager.
 */
class AthenaApiClient private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val authManager = AuthManager.getInstance(appContext)

    // Configure a logging interceptor for debugging network calls
    private val loggingInterceptor = HttpLoggingInterceptor { message ->
        Log.d("Athena:HTTP", message)
    }.apply { level = HttpLoggingInterceptor.Level.BASIC }

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val original = chain.request()
            val builder = original.newBuilder()
            // Attach the bearer token if available
            authManager.getAccessToken()?.let { token ->
                builder.addHeader("Authorization", "Bearer $token")
            }
            chain.proceed(builder.build())
        }
        .addInterceptor(loggingInterceptor)
        .build()

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .client(httpClient)
        .build()

    private val service: AthenaService = retrofit.create(AthenaService::class.java)

    companion object {
        @Volatile private var INSTANCE: AthenaApiClient? = null

        // TODO: point this to your DRF gateway. For development you can use
        // 10.0.2.2:8000 when running against a local emulator or the proper
        // production hostname when deployed.
        private const val BASE_URL = "https://api.athena.example/" // placeholder

        fun getInstance(context: Context): AthenaApiClient {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AthenaApiClient(context).also { INSTANCE = it }
            }
        }
    }

    /**
     * Data transfer object for device attempt requests.
     */
    data class DeviceAttemptRequest(val device_id: String, val app: String, val url: String?, val ts: String)

    data class DeviceAttemptResponse(val runId: String, val decision: String, val sse: String)

    /**
     * Perform a device attempt to request a policy decision from the server.
     */
    suspend fun deviceAttempt(app: String, url: String?): DeviceAttemptResponse {
        // Use current timestamp in ISO format; in a full implementation the
        // device_id should come from SettingsRepository or generated
        val deviceId = SettingsRepository.getInstance(appContext).getDeviceId()
        val ts = java.time.Instant.now().toString()
        val request = DeviceAttemptRequest(deviceId, app, url, ts)
        return withContext(Dispatchers.IO) {
            Log.d("Athena", "AthenaApiClient: sending deviceAttempt for $app $url")
            val response = service.deviceAttempt(request)
            // Map the snake_case JSON to our camelCase fields. Retrofit will
            // handle this for us since we use Moshi.
            DeviceAttemptResponse(
                runId = response.run_id,
                decision = response.decision,
                sse = response.sse
            )
        }
    }

    /**
     * Listens for SSE events for the given run ID. Invokes the callback
     * whenever a decision event is received. Other events (appeal_outcome,
     * run_started, run_completed) are currently ignored but can be handled
     * similarly.
     */
    fun listenForDecision(runId: String, onDecision: (DecisionEvent) -> Unit) {
        val url = "${BASE_URL.trimEnd('/')}/api/runs/$runId/events"
        val request = okhttp3.Request.Builder().url(url).build()
        EventSources.createFactory(httpClient).newEventSource(request, object : EventSourceListener() {
            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                Log.d("Athena", "SSE event: type=$type data=$data")
                if (type == "decision") {
                    // Parse the JSON and invoke the callback
                    try {
                        val adapter = moshi.adapter(DecisionEvent::class.java)
                        val event = adapter.fromJson(data)
                        if (event != null) onDecision(event)
                    } catch (e: Exception) {
                        Log.e("Athena", "Failed to parse decision event", e)
                    }
                }
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: okhttp3.Response?) {
                Log.e("Athena", "SSE connection failed", t)
            }
        })
    }

    /** Retrofit service definition. */
    interface AthenaService {
        @POST("api/device/attempt")
        suspend fun deviceAttempt(@Body request: DeviceAttemptRequest): DeviceAttemptResponseNetwork
        // Additional endpoints (runs, device permit) would be declared here
    }

    /**
     * Data classes that reflect network response structure for Retrofit.
     */
    data class DeviceAttemptResponseNetwork(val run_id: String, val decision: String, val sse: String)

    data class DecisionEvent(
        val decision: Decision,
        val message: String?,
        val ttl: Long,
        val appeal_available: Boolean
    )
}