package com.ironmeerkay.athena

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import java.util.UUID

/**
 * SettingsRepository persists simple key/value settings such as the pause
 * state, deterministic whitelist entries, and hardcode expiry. It uses
 * SharedPreferences for quick access. Longer term data such as rules are
 * stored in Room by LocalPolicyStore.
 */
class SettingsRepository private constructor(private val prefs: SharedPreferences) {

    companion object {
        private const val PREFS_NAME = "athena_settings"
        private const val KEY_PAUSE = "pause_state"
        private const val KEY_HARDCODE_UNTIL = "hardcode_until"
        private const val KEY_DEVICE_ID = "device_id"

        @Volatile private var INSTANCE: SettingsRepository? = null

        fun getInstance(context: Context?): SettingsRepository {
            val appContext = context?.applicationContext ?: throw IllegalArgumentException("Context required")
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsRepository(
                    appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                ).also { INSTANCE = it }
            }
        }
    }

    /**
     * Whether the device is currently paused. When paused the PolicyEngine
     * bypasses blocking decisions unless hardcode mode is active.
     */
    fun isPaused(): Boolean = prefs.getBoolean(KEY_PAUSE, false)

    fun setPause(paused: Boolean) {
        Log.d("Athena", "SettingsRepository: setPause=$paused")
        prefs.edit().putBoolean(KEY_PAUSE, paused).apply()
    }

    /**
     * Returns the timestamp (ms since epoch) when hardcode mode ends, or
     * 0 if not active.
     */
    fun getHardcodeUntil(): Long = prefs.getLong(KEY_HARDCODE_UNTIL, 0L)

    fun setHardcodeUntil(timestampMs: Long) {
        Log.d("Athena", "SettingsRepository: setHardcodeUntil=$timestampMs")
        prefs.edit().putLong(KEY_HARDCODE_UNTIL, timestampMs).apply()
    }

    /**
     * Retrieves or generates a persistent device ID. This ID is used when
     * communicating with the DRF gateway. It's stored the first time
     * getDeviceId() is called.
     */
    fun getDeviceId(): String {
        val existing = prefs.getString(KEY_DEVICE_ID, null)
        if (existing != null) return existing
        val newId = UUID.randomUUID().toString()
        prefs.edit().putString(KEY_DEVICE_ID, newId).apply()
        Log.d("Athena", "SettingsRepository: generated new deviceId=$newId")
        return newId
    }
}