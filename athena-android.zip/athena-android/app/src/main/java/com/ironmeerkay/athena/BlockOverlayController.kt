package com.ironmeerkay.athena

import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * BlockOverlayController centralizes the logic for displaying and
 * dismissing the block overlay. It is invoked by the PolicyEngine when
 * a site or app should be blocked. The overlay is implemented as a
 * dedicated activity to ensure it displays over the current app.
 */
class BlockOverlayController private constructor(private val context: Context) {

    companion object {
        @Volatile private var INSTANCE: BlockOverlayController? = null

        fun getInstance(context: Context): BlockOverlayController {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: BlockOverlayController(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    fun showBlock(reason: String, packageName: String? = null, url: String? = null, runId: String? = null) {
        Log.d("Athena", "BlockOverlayController: showBlock: $reason")
        val intent = Intent(context, BlockOverlayActivity::class.java).apply {
            putExtra(BlockOverlayActivity.EXTRA_REASON, reason)
            putExtra(BlockOverlayActivity.EXTRA_PACKAGE_NAME, packageName)
            putExtra(BlockOverlayActivity.EXTRA_URL, url)
            putExtra(BlockOverlayActivity.EXTRA_RUN_ID, runId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        context.startActivity(intent)
    }

    fun dismiss() {
        // The overlay activity will finish itself after the user chooses
        // an action. There is no explicit dismiss logic needed here.
        Log.d("Athena", "BlockOverlayController: dismiss called")
    }
}