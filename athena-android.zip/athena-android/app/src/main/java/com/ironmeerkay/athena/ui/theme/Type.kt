package com.ironmeerkay.athena.ui.theme

import androidx.compose.material3.Typography

// Set of Material typography styles to start with. You can customize
// these defaults if you wish. See the Compose Material3 library for
// additional options.
val Typography = Typography()