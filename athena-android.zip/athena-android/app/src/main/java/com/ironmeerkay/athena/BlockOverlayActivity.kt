package com.ironmeerkay.athena

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ironmeerkay.athena.ui.theme.AthenaTheme
import android.util.Log

/**
 * BlockOverlayActivity presents a full-screen UI when the current app or
 * website is blocked. Users can appeal the decision or temporarily
 * override it (except in hardcode mode). This activity is launched
 * whenever PolicyEngine decides to block. It is always-on-top and
 * dismisses itself when the user chooses an action.
 */
class BlockOverlayActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val reason = intent.getStringExtra(EXTRA_REASON) ?: "Blocked by policy"
        val packageName = intent.getStringExtra(EXTRA_PACKAGE_NAME)
        val url = intent.getStringExtra(EXTRA_URL)
        val runId = intent.getStringExtra(EXTRA_RUN_ID)
        Log.d("Athena", "BlockOverlayActivity created for $packageName $url: $reason")
        setContent {
            AthenaTheme {
                BlockOverlayScreen(
                    reason = reason,
                    onOverride = {
                        // Insert a temporary whitelist for 5 minutes
                        packageName?.let {
                            LocalPolicyStore.getInstance(this).addTempWhitelist(it, RuleScope.APP, 5)
                        }
                        url?.let {
                            LocalPolicyStore.getInstance(this).addTempWhitelist(it, RuleScope.URL, 5)
                        }
                        // Optionally notify server of permit
                        // Dismiss overlay
                        finish()
                    },
                    onAppeal = {
                        // Navigate to ChatScreen with appeal context. For now
                        // we simply log. In a full implementation this would
                        // open an appeals chat via WebSocket.
                        Log.d("Athena", "Appeal clicked for runId=$runId")
                        finish()
                    }
                )
            }
        }
    }

    companion object {
        const val EXTRA_REASON = "reason"
        const val EXTRA_PACKAGE_NAME = "packageName"
        const val EXTRA_URL = "url"
        const val EXTRA_RUN_ID = "runId"
    }
}

@Composable
fun BlockOverlayScreen(reason: String, onOverride: () -> Unit, onAppeal: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = reason,
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center
        )
        Text(
            text = "Access to this app or website is currently blocked.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center
        )
        Button(onClick = onAppeal) {
            Text(text = "Appeal")
        }
        Button(onClick = onOverride) {
            Text(text = "Override 5 min")
        }
    }
}