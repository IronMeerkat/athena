package com.ironmeerkay.athena

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * ForegroundMonitorService is a minimal foreground service that keeps
 * Athena's monitoring pipeline alive. Starting this service reduces
 * likelihood of the system killing the app when it runs in the
 * background. It posts a persistent notification to comply with
 * Android's foreground service requirements.
 */
class ForegroundMonitorService : Service() {

    override fun onCreate() {
        super.onCreate()
        Log.d("Athena", "ForegroundMonitorService created")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Athena Monitoring Active")
            .setContentText("Monitoring app and web usage")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        startForeground(FOREGROUND_ID, notification)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Athena Monitoring",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager?.createNotificationChannel(channel)
    }

    companion object {
        private const val CHANNEL_ID = "athena_monitoring"
        private const val FOREGROUND_ID = 1
    }
}