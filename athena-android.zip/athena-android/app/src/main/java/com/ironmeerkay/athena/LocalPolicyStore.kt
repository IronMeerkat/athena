package com.ironmeerkay.athena

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

/**
 * Room database for storing policy rules and decisions. There are three tables:
 *  - rules: temp whitelist/blacklist and deterministic whitelist
 *  - decisions: cached decisions with TTL
 *  - settings: miscellaneous key/value settings
 *
 * The LocalPolicyStore provides convenience methods for querying and
 * modifying these tables. Operations are asynchronous where possible.
 */
@Database(entities = [RuleEntity::class, DecisionEntity::class, SettingEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun policyDao(): PolicyDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "athena_database"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}

/** Defines types of rules stored in the rules table. */
enum class RuleType { TEMP_WHITELIST, TEMP_BLACKLIST, DETERMINISTIC_WHITELIST }

/** Defines scopes for rules: app package, domain or full URL. */
enum class RuleScope { APP, DOMAIN, URL }

@Entity(tableName = "rules")
data class RuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val scope: RuleScope,
    val value: String,
    val type: RuleType,
    val expiresAt: Long? = null,
    val source: String? = null
)

@Entity(tableName = "decisions")
data class DecisionEntity(
    @PrimaryKey val key: String,
    val decision: Decision,
    val reason: String?,
    val expiresAt: Long
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val longValue: Long?
)

@Dao
interface PolicyDao {
    @Query("SELECT * FROM rules WHERE type = :type")
    suspend fun getRulesByType(type: RuleType): List<RuleEntity>

    @Query("SELECT * FROM rules WHERE scope = :scope AND value = :value AND (expiresAt IS NULL OR expiresAt > :now)")
    suspend fun getActiveRule(scope: RuleScope, value: String, now: Long): RuleEntity?

    @Insert
    suspend fun insertRule(rule: RuleEntity)

    @Query("DELETE FROM rules WHERE expiresAt < :now")
    suspend fun deleteExpiredRules(now: Long)

    @Query("SELECT * FROM decisions WHERE key = :key AND expiresAt > :now")
    suspend fun getDecision(key: String, now: Long): DecisionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putDecision(decision: DecisionEntity)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings WHERE key = :key")
    suspend fun getSetting(key: String): SettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putSetting(setting: SettingEntity)
}

class LocalPolicyStore private constructor(private val db: AppDatabase) {

    private val dao = db.policyDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    companion object {
        @Volatile
        private var INSTANCE: LocalPolicyStore? = null

        fun getInstance(context: Context): LocalPolicyStore {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: LocalPolicyStore(AppDatabase.getDatabase(context)).also { INSTANCE = it }
            }
        }
    }

    /**
     * Returns true if the given package or URL is allowed according to
     * deterministic and temporary whitelist rules. Blacklists override
     * whitelists. This function runs database queries off the main thread.
     */
    fun isAllowed(packageName: String, url: String?): Boolean {
        val now = System.currentTimeMillis()
        // Note: database queries are blocking here for simplicity. In a real
        // implementation you would call these from a coroutine. We wrap
        // blocking calls into runBlocking scope to simplify usage in the
        // PolicyEngine. Consider using suspend functions throughout.
        return runCatching {
            // Clean up expired rules
            scope.launch { dao.deleteExpiredRules(now) }
            // Check explicit blacklist on URL or domain
            url?.let {
                val domain = extractDomain(it)
                val blacklistRule = dao.getActiveRule(RuleScope.URL, it, now)
                    ?: dao.getActiveRule(RuleScope.DOMAIN, domain, now)
                if (blacklistRule?.type == RuleType.TEMP_BLACKLIST) {
                    return@runCatching false
                }
            }
            // Check app level blacklist
            val pkgBlacklist = dao.getActiveRule(RuleScope.APP, packageName, now)
            if (pkgBlacklist?.type == RuleType.TEMP_BLACKLIST) {
                return@runCatching false
            }
            // Check app deterministic whitelist
            val pkgWhitelist = dao.getActiveRule(RuleScope.APP, packageName, now)
            if (pkgWhitelist?.type == RuleType.DETERMINISTIC_WHITELIST || pkgWhitelist?.type == RuleType.TEMP_WHITELIST) {
                return@runCatching true
            }
            // Check domain whitelist
            url?.let {
                val domain = extractDomain(it)
                val domainRule = dao.getActiveRule(RuleScope.DOMAIN, domain, now)
                if (domainRule?.type == RuleType.DETERMINISTIC_WHITELIST || domainRule?.type == RuleType.TEMP_WHITELIST) {
                    return@runCatching true
                }
            }
            false
        }.getOrDefault(false)
    }

    /**
     * Add a temporary whitelist entry for the given package or URL. TTL is
     * specified in minutes.
     */
    fun addTempWhitelist(value: String, scope: RuleScope, ttlMinutes: Long) {
        val expiresAt = System.currentTimeMillis() + ttlMinutes * 60_000
        val rule = RuleEntity(scope = scope, value = value, type = RuleType.TEMP_WHITELIST, expiresAt = expiresAt)
        scope.launch {
            dao.insertRule(rule)
        }
    }

    /**
     * Extracts the domain portion of a URL. This simple helper does not
     * perform full parsing or international domain name normalization but
     * suffices for the demo.
     */
    private fun extractDomain(url: String): String {
        return try {
            val uri = java.net.URI(url)
            uri.host ?: url
        } catch (e: Exception) {
            url
        }
    }

    /**
     * Convenience for retrieving the deterministic whitelist. Used in
     * settings screens. Returns a list of app package names and domains.
     */
    suspend fun getDeterministicWhitelist(): List<RuleEntity> {
        return dao.getRulesByType(RuleType.DETERMINISTIC_WHITELIST)
    }
}